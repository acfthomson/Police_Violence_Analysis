# Police Violence and Racial Equity Analysis

## Introduction 

We are doing analysis on police violence across states and evaluate the more prone to violence states and the potential causes.

The analysis will cover wide range of questions and will be using various data analytics tool like (Python Libaries , Machine Learning Model) , Tableau , Postgress Sql.

## Resources 
Machine Learning (Python)
Database: Postgress
Host Instance: AWS RDS
Analytics: Tableau
## Team 
Tamara 
Nigel
Amanda
Shivam

## Communications Protocols 
We will be meeting twice the week and checking on What has been accomplished and what will be accomplished in coming weeks

## Links 

## Project Description 
The Machine learning model will be trained to depict how much accuracy shootings were accurate.

## Conclusion 
How many shootings happen in US and how much it will increase in coming years .
