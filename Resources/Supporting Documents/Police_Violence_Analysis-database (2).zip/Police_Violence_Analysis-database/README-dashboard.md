# Dashboard Skeleton 
The Dashboard Consists of various visuals with interactive filter

## What infographics will we include? 
1. Doughnut Chart
2. Tableaur Table Data 
3. Coorelation Graphs

## What questions are we answering?
1. Top States By Count of Police Killings of Civilians
2. Overall Count of Civilian Death by Race
3. Correlation Between The Age Of The Victims And Whether They Fled
4. Total Population By Race
5.  Budget Data For Police Stations Across The US In 2013-2017
 
## What is the order of the infographics, what is our sketch like? 
